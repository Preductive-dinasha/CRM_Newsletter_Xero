import { MessageCircle, Menu, Paperclip, Mic, Send } from 'lucide-react';
import { useState } from 'react';

export function ChatArea() {
  const [message, setMessage] = useState('');
  const [selectedAgent, setSelectedAgent] = useState('@CRM');

  return (
    <div className="flex-1 flex flex-col bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
        <button className="p-2 hover:bg-gray-100 rounded-md">
          <Menu className="w-5 h-5 text-gray-600" />
        </button>
        <button className="px-4 py-1.5 bg-orange-500 text-white rounded-full text-sm hover:bg-orange-600 transition-colors">
          {selectedAgent}
        </button>
      </div>

      {/* Empty State */}
      <div className="flex-1 flex items-center justify-center">
        <div className="text-center">
          <div className="w-20 h-20 bg-gray-100 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <MessageCircle className="w-10 h-10 text-gray-600" />
          </div>
          <h1 className="text-3xl font-semibold text-gray-900 mb-2">
            How can I help you?
          </h1>
          <p className="text-gray-500">
            Select an agent below, then type your message
          </p>
        </div>
      </div>

      {/* Input Area */}
      <div className="bg-white border-t border-gray-200 p-6">
        <div className="max-w-4xl mx-auto">
          <div className="relative">
            <div className="flex items-center gap-2 bg-white border border-gray-300 rounded-lg shadow-sm focus-within:border-gray-400 focus-within:ring-2 focus-within:ring-gray-100 transition-all">
              <button className="p-3 hover:bg-gray-50 rounded-l-lg">
                <Paperclip className="w-5 h-5 text-gray-500" />
              </button>
              <button className="p-3 hover:bg-gray-50">
                <Mic className="w-5 h-5 text-gray-500" />
              </button>
              <input
                type="text"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Message Preddi... (@ to pick a skill)"
                className="flex-1 py-3 px-2 outline-none"
              />
              <select
                value={selectedAgent}
                onChange={(e) => setSelectedAgent(e.target.value)}
                className="px-3 py-2 text-gray-700 border-l border-gray-200 outline-none bg-transparent cursor-pointer hover:bg-gray-50"
              >
                <option>@CRM</option>
                <option>@Sales</option>
                <option>@Support</option>
                <option>@Analytics</option>
              </select>
              <button className="p-3 hover:bg-gray-50 rounded-r-lg">
                <Send className="w-5 h-5 text-gray-400" />
              </button>
            </div>
          </div>
          <div className="text-xs text-gray-400 mt-2 text-center">
            Enter to send · Shift+Enter for new line · @ to pick a skill
          </div>
        </div>
      </div>
    </div>
  );
}
