import { MessageSquare, Plus } from 'lucide-react';

interface SidebarProps {
  onNewChat: () => void;
}

export function Sidebar({ onNewChat }: SidebarProps) {
  return (
    <div className="w-80 bg-white border-r border-gray-200 flex flex-col h-screen">
      {/* Header */}
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-8 h-8 bg-gray-800 rounded flex items-center justify-center">
            <MessageSquare className="w-5 h-5 text-white" />
          </div>
          <span className="text-xl font-semibold text-gray-900">Preddi</span>
        </div>
        <button
          onClick={onNewChat}
          className="w-full flex items-center gap-2 px-4 py-2 bg-gray-900 hover:bg-gray-800 text-white rounded-md transition-colors"
        >
          <Plus className="w-5 h-5" />
          <span>New Chat</span>
        </button>
      </div>

      {/* Recent Chats */}
      <div className="flex-1 overflow-y-auto">
        <div className="p-4">
          <div className="text-xs text-gray-500 mb-2">Recent</div>
          <div className="space-y-1">
            <button className="w-full text-left px-3 py-2 text-gray-700 hover:bg-gray-100 rounded-md transition-colors">
              Find Andrew
            </button>
            <button className="w-full text-left px-3 py-2 text-gray-700 hover:bg-gray-100 rounded-md transition-colors">
              andrew
            </button>
          </div>
        </div>
      </div>

      {/* User Info */}
      <div className="p-4 border-t border-gray-200">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-gray-700 rounded-full flex items-center justify-center text-white">
            D
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-sm font-medium text-gray-900 truncate">Dinasha</div>
            <div className="text-xs text-gray-500 truncate">dinasha@productive.co</div>
          </div>
        </div>
      </div>
    </div>
  );
}
