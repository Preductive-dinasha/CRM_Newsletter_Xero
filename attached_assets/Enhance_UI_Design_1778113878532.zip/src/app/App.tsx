import { Sidebar } from './components/Sidebar';
import { ChatArea } from './components/ChatArea';

export default function App() {
  const handleNewChat = () => {
    console.log('New chat created');
  };

  return (
    <div className="size-full flex">
      <Sidebar onNewChat={handleNewChat} />
      <ChatArea />
    </div>
  );
}